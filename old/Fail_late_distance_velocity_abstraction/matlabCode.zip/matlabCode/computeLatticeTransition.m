function [df,vf] = computeLatticeTransition(d,v,N,K,deltad,deltav,B1,B2,fmu,amax,Thd,xThresh,TTCThresh,freq)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
    db=d+deltad;
    vb=v-deltav;
    
    for i=1:N
        v = max(0,v);
        vb = max(0,vb);
        if(i<=N-K)
            d=d-v/freq;
            db=db-vb/freq;
        else
            d=d-v/freq;
            db=db-vb/freq;
            brakingPower = computeAEBSPower(d,v,fmu,amax,Thd,xThresh,TTCThresh,B1,B2);
            v=v-brakingPower/freq;
            vb=vb-brakingPower/freq;
        end
    end
    df = d-mod(d,deltad);
    if mod(v,deltav)==0
        vf = v;
    else
        vf = v+deltav-mod(v,deltav);
    end
end

function braking = computeAEBSPower(d,v,fmu,amax,Thd,xThresh,TTCThresh,B1,B2)
    AEBSRegion = computeAEBSRegion(d,v,fmu,amax,Thd,xThresh,TTCThresh);
    braking = (AEBSRegion==0)*0+(AEBSRegion==1)*B1 + (AEBSRegion==2)*B2;
end

function contRegion = computeAEBSRegion(d,v,fmu,amax,Thd,xThresh,TTCThresh)

    x = (d - fmu*v.^2/(2*amax))./(d*Thd);
    y = (d./v);

    contRegion = 1*(x<=xThresh) + 1*(y<=TTCThresh);


end